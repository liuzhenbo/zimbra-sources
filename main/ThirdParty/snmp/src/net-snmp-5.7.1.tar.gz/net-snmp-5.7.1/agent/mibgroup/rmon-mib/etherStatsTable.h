/*
 * module to include the modules
 */

config_require(rmon-mib/data_access/etherstats)
config_require(rmon-mib/etherStatsTable/etherStatsTable)
config_require(rmon-mib/etherStatsTable/etherStatsTable_data_get)
config_require(rmon-mib/etherStatsTable/etherStatsTable_data_set)
config_require(rmon-mib/etherStatsTable/etherStatsTable_data_access) 
config_require(rmon-mib/etherStatsTable/etherStatsTable_interface)

